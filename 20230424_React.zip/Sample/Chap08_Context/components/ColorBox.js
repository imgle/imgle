import React from "react";

function ColorBox() {
  return (
    <div>
      <div></div>
    </div>
  );
}
export default ColorBox;
