import React from "react";

function A04History() {
  return (
    <div>
      <h5>Product Component</h5>
      <div>This is Product Component</div>
      <br />

      <div>
        <button>BACK</button>
        <button>FORWARD</button>
        <button>HOME</button>
        <button>PARAMETER</button>
      </div>
    </div>
  );
};
export default A04History;
