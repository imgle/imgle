import React from 'react'

function A08Redirect() {
  const isChecked = false;

  if(!isChecked) { 
    
  }

  return (
    <div>
      <h1>A08Redirect</h1>
    </div>
  )
}

export default A08Redirect