function App() {
  const user = {name: 'HungBu', age: 20};
  const ary = ['a', 'b', 'c'];
  const onAdd = (x, y) => `${x} + ${y} = ${x + y}`;

  return (
    <div className="m-3">
      
    </div>
  );
}

export default App;

// npm i react-router-dom
// npm i react-loader-spinner
