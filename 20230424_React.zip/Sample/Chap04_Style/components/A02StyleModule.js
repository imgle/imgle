import React from "react";

function A02StyleModule() {
  return (
    <div>
      <h3>A02 Style <span>Module</span> Component</h3>
      <h3>A02 Style Module Component</h3>
      <h3>A02 Style Module Component</h3>
    </div>
  );
}

export default A02StyleModule;
