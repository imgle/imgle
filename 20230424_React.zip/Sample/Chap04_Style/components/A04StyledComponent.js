// npm i styled-components
// npm i reactstrap
// npm i react-icons

import React from "react";

function A04StyledComponent() {
  return (
    <div>
      <h3>A04 Styled Component</h3>
    </div>
  );
}

export default A04StyledComponent;
