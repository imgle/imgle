import React from "react";
// npm i classnames

function A03Classnames() {
  const text = "text";
  const isChecked = true;

  return (
    <div>
      <h3>A03 ClassNames Module</h3>
      <h3>A03 ClassNames Module</h3>
      <h3>A03 ClassNames Module</h3>
    </div>
  );
}

export default A03Classnames;
