import React from "react";

function Counter(props) {
  return (
    <div>
      <h3>Counter: </h3>
      <button>+</button>
      <button>-</button>
    </div>
  );
}
export default Counter;
