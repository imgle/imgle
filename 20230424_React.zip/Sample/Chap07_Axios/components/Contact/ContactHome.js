import React from "react";

function ContactHome() {
  return (
    <div>
      <h3>Welcome to Contact Page</h3>
    </div>
  );
}
export default ContactHome;
