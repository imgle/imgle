import A01Axios from "./components/A01Axios";

function App() {
  return (
    <div className="m-3">
      <h1>Axios</h1>

      <A01Axios />
    </div>
  );
}

export default App;

// npm i react-router-dom axios
