import React from "react";

function A09HigherOrder(props) {
  return (
    <div>
      <h3>A09 Higher Order Component</h3>
      props: {props.name}
      <br />

      Age: 
      <br />
      
      <button>AGE</button>
    </div>
  );
}

export default A07HigherOrder;
