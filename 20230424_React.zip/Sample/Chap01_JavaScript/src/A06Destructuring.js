const obj = {
    name: 'NolBu',
    age: 30
}

const ary = ['A', 'B', 'C'];
console.log(obj, ary);