// 일반 함수. 
function fn(){
    console.log('funcion');
}
fn();

const ary = [10, 11, 100, 101, 1000];

// 익명함수(이름이 없는 함수)
    