// 변수.
var nickname = 'A';
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);

nickname = 100;
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);

nickname = true;
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);

// undefined, null, symbol
nickname = null;
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);

// 참조형 typeof가 모두 object로 표시된다
nickname = [1, 2];
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);
console.log('');


// 호이스팅
// 실행전 문서 스캔. 이때 변수와 함수를 먼저 메모리에 올리는 작업을 한다
// 변수 => undefined로 초기화
// 함수 => 완벽하게 기술된 상태로 초기화 (중복 이름이 있으면 덮어 씀)
console.log(age);
var age = 10;
console.log('age: ' + age + ', typeof 변수명: ' + typeof age);


// 문제점
// 1. 선언된 변수를 재 선언해도 에러 아님 (호이스팅 과정에서 재 선언 SKIP)
var nickname = 'Hello World';
console.log('nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);

// 2. 변수나 함수가 { } 범위(지역변수 역할)를 갖지 않는다
// 함수만 { } 범위를 갖는다
if (true) {
  var nickname = 'Inner Nickname';
  console.log('IN nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);
}
console.log('OUT nickname: ' + nickname + ', typeof 변수명: ' + typeof nickname);
console.log('')

// 3번만 반복된다. i 변수가 global에 등록되고 같이 사용하게 된다
for (var i = 0; i < 3; i++) {
  for (var i = 0; i < 3; i++) {
    console.log(i)
  }
}
console.log(i);               // 4
console.log('')

// 3. Global(window)영역을 오염시킨다
console.log(window);
var A = 0;
// var alert = 10;              // 주석 해제 후 확인 
// alert('Hello World');        // Error
console.log('');


// ES2015(ES6)

// let
// 1. var와 동일하게 동적타입이다. 다만 선언한 변수를 재 선언할 수 없다
let address = 'Seoul';
console.log('address: ' + address + ', typeof 변수명: ' + typeof address);

// let address = 'A';       // Error
// var address = 'A';       // Error
// const address = 'A';     // Error


// 2. 모든 { }에서 변수 참조 범위를 갖는다
if (true) {
  let address = 10;           // 지역변수 } 만나면 삭제된다
  console.log('IN address: ' + address + ', typeof 변수명: ' + typeof address);
}
console.log('Out address: ' + address + ', typeof 변수명: ' + typeof address);

for (let k = 0; k < 3; k++) {
  for (let k = 0; k < 3; k++) {
    console.log(k)
  }
}
// console.log(k);          // Error

// 3. Global 영역(window)를 오염시키지 않는다
// TDZ(선언과 초기화 사이)에 정의된다 (확인은 안됨)
let A1 = 10
console.log(window)

let alert = 'Hello World';
console.log(alert);       // TDZ의 alert
window.alert('Hi~~')      // window 영역에 있는 alert
console.log('');

// const 상수 선언
const MY_PI = 3.14159;
console.log('MY_PI: ' + MY_PI + ', typeof 변수명: ' + typeof MY_PI);

// 초기화 후 값 변경 불가
// MY_PI = 100;           // Error

// 선언시 초기화 하지 않으면 에러. 추후에 값 변경이 안된다
// const MY_STR;

const arr = [1, 2];
arr[0] = 10;
console.log(arr)

// arr = [20, 30];        // Error
console.log('')

const user = { name: 'A', num: 10 };
user.name = 'B';
console.log(user);

// user = { address: 'Seoul' };     // Error

