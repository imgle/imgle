const obj = { _name: 'NolBu', _kor: 100, _eng: 80 };

class Jumsu {
  // ES2022
  #name;      // private. THIS로만 참조할 수 있는 변수

  // 생성자 메서드
  constructor(name, kor, eng) {
    // const this = {};
    this.#name = name;
    this._kor = kor;
    this._eng = eng;
    // return this;
  }

  getTotal() {
    return this._kor + this._eng;
  }
  getAvg() {
    return this.getTotal() / 2;
  }
  display() {
    console.log(`${this.#name} / ${this.getTotal()} / ${this.getAvg()}`)
  }

  // 일반 메서드
  getKor() {
    return this._kor
  }
  setKor(kor) {
    this._kor = kor;
  }

  // Getter, Setter Method
  // 선언은 함수 형태로 선언. 사용은 프로퍼티 방식으로 사용
  get name() {
    return this.#name
  };
  set name(name) {
    this.#name = name;
  }
}
const nolbu = new Jumsu('Nolbu', 100, 80);      // new Jumsu.contstrctor()
const hungbu = new Jumsu('Hungbu', 90, 80);

console.log(nolbu);
console.log(hungbu);

const arr = [nolbu, hungbu];
arr.forEach((item => item.display()))
console.log('')

console.log(nolbu._kor);
// console.log(nolbu.#name)
console.log('')

console.log(nolbu.getKor());
nolbu.setKor(20);
console.log(nolbu.getKor());
console.log('');

console.log(nolbu.name);
nolbu.name = '놀부';
console.log(nolbu.name);