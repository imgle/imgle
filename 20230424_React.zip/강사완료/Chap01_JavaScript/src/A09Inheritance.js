class Jumsu {
    #name
    constructor(name, kor, eng) {
        this.#name = name;
        this._kor = kor;
        this._eng = eng;
    }

    getTotal() {
        return this._kor + this._eng;
    }
    getAvg() {
        return this.getTotal() / 2;
    }
    display() {
        console.log(`${this.#name} / ${this.getTotal()} / ${this.getAvg()}`)
    }
    get name() {
        return this.#name
    };
    set name(name) {
        this.#name = name;
    }
}

// JumsuTwo의 부모 객체로 Jumsu를 지정하겠다
class JumsuTwo extends Jumsu { }

// 부모와 다를때만 재 정의
class JumsuThree extends Jumsu {
    constructor(name, kor, eng, math) {
        // 생성자 메서드에서 부모 생성자 메서드를 무엇보다 먼저 호출해야 한다

        // Jumsu의 생성자 메서드들 호출
        // 이 명령에 의해 부모 자료구조가 먼저 생성된다
        super(name, kor, eng);      // 부모의 자료구조 이용
        // this._name = name;
        // this._kor = kor;
        // this._eng = eng;
        this._math = math;
    }

    // override. 부모가 가진 메서드를 같은 이름으로 재 정의
    getTotal() {
        return this._kor + this._eng + this._math;
    }
    getAvg() {
        return this.getTotal() / 3;
    }
}

const nolbu = new JumsuTwo('Nolbu', 100, 80);
const hungbu = new JumsuTwo('Hungbu', 90, 80);

const hangdan = new JumsuThree('향단', 100, 90, 80);

// console.log(nolbu)
nolbu.display();
hungbu.display();
hangdan.display()

