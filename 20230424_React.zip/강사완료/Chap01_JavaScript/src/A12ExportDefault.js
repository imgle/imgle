// A12ExportDefault.js
const app = (function () {
  const x = 10;
  const alert = 'Hello World';

  const onMin = (x, y) => `${x} - ${y} = ${x - y}`;
  const info = () => console.log(`x: ${x}, alert: ${alert}`);

  return {
    x: x,
    onMin: onMin,
    info: info
  }
})()
// console.log(app)

// default는 문서에서 1개의 요소만 지정할 수 있음 (두번 지정 안됨)
export default app;

// default와 함께 개별요소 export는 사용 가능
export const y = 20;

const longNameVar = 30;
export { longNameVar as lname }