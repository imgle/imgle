// 외부 파일에서 export 한 변수, 함수를 로드
// 디스터럭처링 구문과 동일. export 이름과 동일한 이름으로 선언해야 한다
// 이미 변수명이 사용되고 있다면 as로 Alias를 선언해서 사용 가능
import { nickname, num, arr, onAdd as add } from './A12Export.js'

console.log(nickname, num, arr[0]);
console.log(add(10, 20));
console.log('')

// default로 export 된 항목은 import로 호출할때 임의의 이름으로 호출 가능
import root, { y, lname } from './A12ExportDefault.js'
// import { y } from './A12ExportDefault.js'
// console.log(root)
console.log(root.x);
console.log(root.onMin(20, 1));
root.info();
console.log(y);
console.log(lname);

