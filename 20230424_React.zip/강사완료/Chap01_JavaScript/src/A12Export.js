// A12Export.js

// 개별적으로 외부 파일에서 import 구문으로 사용할 수 있도록 허용
export const nickname = 'A12 Export';
export const num = 10;

const arr = [1, 2];
const onAdd = (x, y) => `${x} + ${y} = ${x + y}`;

// 이렇게 한번에 묶어 사용도 가능. (병행 사용도 가능)
export { arr, onAdd }

console.log(nickname);
