// 일반 함수. 
function fn() {
    console.log('funcion');
}
fn();

const arr = [10, 11, 100, 101, 1000];

// 익명함수(이름이 없는 함수)
const one = function abc() { }
console.dir(one)

// 순환 함수
let total = 0;
arr.forEach(function (item, index, arr) {
    // console.log(item, index, arr);
    total += item;
});
console.log(total);

total = 0;
arr.forEach(item => total += item);
console.log(total);

// 순환 후 새로운 배열을 만들어 리턴 => map
// 리턴 값으로 새로운 배열을 만들어준다. 기존배열은 변동사항 없음(불변성)
// react에서 요소의 변경때 사용
const mapArr01 = arr.map(function (item, index, arr) {
    if (item % 2 === 0) return item * 2;
    else return item * 3;
});
console.log(mapArr01);
console.log(arr);

const mapArr02 = arr.map((item) => (item % 2 === 0) ? item * 2 : item * 3);
console.log(mapArr02);
console.log('');

// filter => 걸러낼 목적으로 사용. 리턴값이 true인 요소만 모아서 새로운 배열 생성
// react에서는 삭제때 사용
const filterArr01 = arr.filter(function (item, index, arr) {
    if (item % 2 === 0) return true;
    else return false;
});
console.log(filterArr01);

const filterArr02 = arr.filter((item) => (item % 2 === 0) ? true : false);
console.log(filterArr01);

// find, findIndex
const user = [
    { id: 1, name: 'A', age: 10 },
    { id: 2, name: 'B', age: 20 },
    { id: 3, name: 'C', age: 30 },
]

// Immer 사용하는 경우 자주 사용됨
const getUser = (id) => user[id];
const getIndex = (id) => {
    const idx = user.findIndex((item) => item.id === id)
    // return idx
    return user[idx];
}
const getItem = (id) => user.find((item) => item.id === id);

console.log(getUser(1));
console.log(getIndex(1))
console.log(getItem(1))
