// ES6
// 구조화된 요소를 각각의 개별 요소로 참조 할 목적으로 사용한다
// 구조 내부의 요소를 참조만 함 => 스프레드 연산자
// 구조 내부의 요소의 값을 꺼내와 사용 => 디스트럭처링
console.log([10, 11, 100]);
console.log([10, 11, 100][0], [10, 11, 100][1], [10, 11, 100][2]);
console.log(...[10, 11, 100]);

console.log('NolBu');
console.log(...'NolBu');
console.log('');

// ...rest는 나머지 매개변수를 의미. 이전의 argumensts라는 내부 변수와 비슷 
function spreadFun(a, b, c, d, e, ...rest) {
    console.log(`a => ${a}`);
    console.log(`b => ${b}`);
    console.log(`c => ${c}`);
    console.log(`d => ${d}`);
    console.log(`e => ${e}`);
    console.log(`rest => ${rest} / ${rest.length}`);
}

spreadFun(0, ...[10, 20, 30], 40, ...[50, 60, 70]);
console.log('')

// React
// 배열 합치기.
const aryOne = [10, 20, 30];
const aryTwo = [1, 2, 3, ...aryOne];
// 합쳐진 새로운 배열이 만들어진다
console.log(aryTwo);
console.log('');

// 맨 뒤에 추가
const arr = [1, 2, 3];
// arr.push(4);                 // 기존 배열에 추가됨
const newArr = arr.concat(4);   // 기존 배열의 뒤에 요소를 추가해서 새로운 배열 리턴
console.log(arr, newArr);
console.log(arr === newArr);
console.log('');

// 중간에 추가 / 삭제는 map, filter 사용


// Object
const objOne = {
    id: 1,
    name: 'NolBu'
};

const objTwo = {
    id: 2,
    address: 'Seoul',
}
// 새로운 객체를 생성해서 반환
const newObj01 = {
    ...objOne
}
console.log(newObj01);
console.log(objOne === newObj01);

// 키가 중복되면 나중에 오는 값으로 덮어쓴다
const newObj02 = {
    ...objOne,
    ...objTwo
}
console.log(newObj02)

const objThree = {
    id: 3,
    address: 'InChen',
}

const newObj03 = {
    ...objThree,
    ...objOne,
}
console.log(newObj03)
