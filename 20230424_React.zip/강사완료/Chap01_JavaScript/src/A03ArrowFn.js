// 함수 리터럴. 함수 표현식
const onAdd = function (x, y) {
  console.log(`${x} + ${y} = ${x + y}`);
}

const onMin = function (x, y) {
  return `${x} - ${y} = ${x - y}`;
}

onAdd(10, 20);
console.log(onMin(10, 20));
console.log('')


// ES6. 
// 함수 리터럴 방식만 변경 가능
// 1. function을 삭제하고 인수 뒤를 =>로 변경 () => {} 형태가 된다
const one = (x, y) => {
  console.log(`${x} + ${y} = ${x + y}`);
}

// 2. 함수의 { } 구문이 1줄인 경우 { }와 return을 생략하고 한 줄에 기술한다
// => 다음 구문이 실행 구문의 경우 그대로 실행
// => 다음 구문이 값인 경우 값 앞에 return을 추가해서 실행

// { } 내부에 구문이 1줄 이상인 경우는 { }로 묶어야 하고, 리턴값이 있으면 return 붙여야 한다
// (기존과 동일)
const two = (x, y) => console.log(`${x} + ${y} = ${x + y}`);
const three = (x, y) => `${x} + ${y} = ${x + y}`;

two(10, 20);
console.log(three(10, 20));

// 3. 매개변수가 1개인 경우 ()를 생략할 수 있다
// ** 연산자는 ES6에서 추가 (2의 3승)
const four = x => 2 ** x;
console.log(four(3))          // 2 * 2 * 2


// 4. 함수의 매개변수에 기본값 할당이 가능하다 (일반 함수도 동일)
const five = (x = 0, y = 0) => `${x} + ${y} = ${x + y}`;
console.log(five());
console.log(five(10, 20));
console.log('');

// 5. Arrow 함수는 this가 존재하지 않는다.
// 자신을 포함한 상위 객체의 this를 자신의 this로 사용한다
window.name = 'Window';
this.age = 100;

console.log(this)
const user = {
  name: 'NolBu',
  age: 30,
  info() {
    console.log(`${this.name} / ${this.age}`)
  },
  view: () => {
    // user가 참조하는 this(window)의 name과 age를 출력한다
    // 함수 자체의 this는 존재하지 않는다
    console.log(`${this.name} / ${this.age}`)
  }
}
user.info();
user.view();    // 
console.log(window)
