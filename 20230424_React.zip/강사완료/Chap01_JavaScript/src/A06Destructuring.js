// ES6
// 구조화된 요소를 각각의 개별 요소의 값을 별도의 변수에 저장할 목적으로 사용한다
// 구조 내부의 요소를 참조만 함 => 스프레드 연산자
// 구조 내부의 요소의 값을 꺼내와 사용 => 디스트럭처링
const obj = {
    name: 'NolBu',
    age: 30
}

// 기존 방식
// const name = obj.name;
// const age = obj.age;

// 1. 변수명은 객체의 키와 동일한 이름으로 선언해야 한다
const { name, age } = obj;
console.log(name, age);

// 2. 이미 변수명을 사용하고 있다면 별칭(Alias)를 이용
const { name: nickname, age: num } = obj;
console.log(nickname, num);

// 3. 기본값 할당 가능
// 배열, 함수는 변수 자체가 선언되어 있다면 없는 요소값을 참조해도 에러가 아니다
const { name: x = 'Unknown', age: y = 0, address = 'Seoul' } = obj;
console.log(x, y, address);
console.log('');

const user = {
    name: 'A'
}
// console.log(userObj);            // 선언 안됨. Error
console.log(user.name, user.age);   // 변수는 선언됨. 참조 요소가 없음(undefined)

const arr = [10];
// console.log(myArr);              // 선언 안됨. Error
console.log(arr[0], arr[10]);       // 변수는 선언됨. 참조 요소가 없음(undefined)
console.log('')

// 배열은 별칭(Alias)가 없음. 따라서 중복되지 않는 변수명으로 선언해야 한다
// []로 참조
const ary = ['A', 'B', 'C'];
const [a, b, c] = ary;
console.log(a, b, c);

// skip. ,로 건너뛴다
const [, , c1] = ary;
console.log(c1);

const [a2, , c2] = ary;
console.log(a2, c2);
console.log('');

// 원본은 변동사항 없음
console.log(obj, ary);