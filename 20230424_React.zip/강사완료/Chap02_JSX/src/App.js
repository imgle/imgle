// JSX (JavaScript XML)
// 1. 문자열이 아닌 태그로 시작한다
/*
const elem = <h1>Hello World 01</h1>

function App() {
  return elem;
}
export default App;
*/

/*
// 함수 내부에서 구현도 가능
function App() {
  return <h1>Hello World 02</h1>;
}
export default App;
*/

// 2. 한개의 요소만 리턴 가능하다
// 구성 요소를 한개의 태그로 감싸야 한다

/*
const elem =
  <div>
    <h1>Hello World 03</h1>
    <div>This is Content</div>
  </div>

function App() {
  return elem;
}
export default App;
*/

// default export 이므로 임의의 이름으로 호출해서 사용
import ABC from './components/A01Component'
import A02Fragment from './components/A02Fragment'
import A03JQuery from './components/A03JQuery'

// 일반 선언 변수는 읽기 전용이다. (감시자가 붙지 않음)
let name = '놀부';
const age = 20;
const arr = [10, 20];
const user = { name: '흥부', age: 30 }
const onAdd = (x = 0, y = 0) => `${x} + ${y} = ${x + y}`;
const changeName = () => name = 'Hello World';

const makeDOM = () => (
  <div>
    <h3>makeDOM</h3>
    <div>함수의 이름이 소문자로 시작되었음</div>
  </div>
)

const MakeDOM = () => (
  <div>
    <h3>MakeDOM</h3>
    <div>함수의 이름이 대문자로 시작되었음</div>
  </div>
)



function App() {
  return (
    <div className="m-3">
      <h1>Hello World 04</h1>
      <div>
        <h3>바인딩 / 보간법</h3>
        중괄호 내부에는 변수, 함수, 연산자, 이벤트 등을 호출<br />
        Name: {name}<br />
        Age: {age}<br />
        {/* undefined, null, false, true 값은 화면에 표시되지 않는다 */}
        Age: {arr[0]} / {arr[1]} / {arr[10]}<br />
        User: {user.name} / {user.age} / {user.address}<br />
        onAdd: {onAdd(10, 20)}<br />
        연산자 사용: {1 + 2} / {user.address ? user.address : '주소 없음'}<br />
        <button onClick={changeName}>Name</button>
      </div>
      <br />

      <div>
        This is Content<br />
        모든 태그는 종료 태그가 있어야 한다<br />
        태그의 속성은 JavaScript 요소 속성을 따른다<br />

        public 폴더 내부의 파일은 public 생략하고 경로 기술<br />
        JSX는 HTML validate로 체크<br />
        <img src="images/tree.jpg" alt="사진" />
      </div>
      <br />

      {makeDOM()}
      <br />

      <MakeDOM />
      <br />

      <ABC></ABC><br />
      <A02Fragment></A02Fragment><br />
      <A03JQuery></A03JQuery>
    </div>
  )
}
export default App;
