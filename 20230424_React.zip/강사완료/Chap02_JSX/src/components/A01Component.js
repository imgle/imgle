// A01Component.js

function A01Component() {
  const name = 'HangDan';

  return (
    <div>
      <h3>A01 Component</h3>
      <div>
        My name is {name}<br />
      </div>
    </div>
  )
}
export default A01Component;
