// A02Fragment.js
import React, { Fragment } from 'react'

function A02Fragment() {
  return (
    <Fragment>
      <h3>A02Fragment</h3>

      <>
        This is Conetent<br />
        Fragment는 컴파일될때 삭제된다. 빈 태그도 동일
      </>
    </Fragment>
  )
}

export default A02Fragment
