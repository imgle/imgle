import React from 'react'
import $ from 'jquery'

$(function () {
  $('#btn').click(function (evt) {
    const qty = $('#qty').val();
    const cost = $('#cost').val();

    $('#total').html(qty * cost);
  })
});

function A03JQuery() {

  const clickEvent = () => {
    const qty = $('#qty').val();
    const cost = $('#cost').val();

    $('#total').html(qty * cost);
  }

  return (
    <div>
      <h3>jQuery</h3>
      Qty
      <input type="text" id="qty" className="form-control" />
      Cost
      <input type="text" id="cost" className="form-control" />

      <div id="total"></div>
      <button id="btn">Click</button>
      <button onClick={clickEvent}>Click</button>
    </div>
  )
}

export default A03JQuery
