import TodoTemplate from './components/TodoTemplate'

function App() {
  return (
    <div className="m-3">
      <h1>Chap05 TodoList</h1>

      {/* TodoList Container Component */}
      <TodoTemplate></TodoTemplate>
    </div>
  );
}

export default App;
