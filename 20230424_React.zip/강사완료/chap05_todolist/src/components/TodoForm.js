import React, { useRef, useState } from "react";

function TodoForm(props) {
  const { addTodo } = props;
  const [txt, setTxt] = useState('');
  const todoRef = useRef();

  const changeText = (evt) => {
    setTxt(evt.target.value)
  }
  const sendData = (evt) => {
    evt.preventDefault();
    /*
    if (txt.trim().length !== 0) {
      addTodo(txt);
      setTxt('');
      todoRef.current.focus();
    }
    */
    const value = todoRef.current.value;
    if (value.trim().length !== 0) {
      addTodo(txt);
      todoRef.current.value = '';
      todoRef.current.focus();
    }
  }

  return (
    <form>
      <div className="input-group">
        <input type="text" className="form-control" ref={todoRef} onChange={changeText} />
        <div className="input-group-append">
          <button type="submit" className="btn btn-primary mr-1" onClick={sendData}>Submit</button>
        </div>
      </div>
    </form>
  );
}
export default TodoForm;
