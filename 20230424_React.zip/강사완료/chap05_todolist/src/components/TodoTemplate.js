import React, { useCallback, useRef, useState } from "react";
import TodoForm from './TodoForm'
import TodoList from './TodoList'

const makeTodo = () => {
  const todos = [];
  for (let i = 1; i <= 5000; i++) {
    todos.push({ id: i, text: `${i}번째 할 일`, done: false });
  }
  return todos;
};
// const todoList = [
//   {id: 1, text: '1번째 할 일', done: false},
//   {id: 2, text: '2번째 할 일', done: false},
// ]

const TodoTemplate = () => {
  const [todoList, setTodoList] = useState(makeTodo());
  // console.log(todoList)
  const cnt = useRef(5001);

  const updateTodo = useCallback((id) => {
    /*
    // item => {id: 2, text: '2번째 할 일', done: false},
    // const todos = todoList.map( todo => todo.id === id ? {...todo, done: !todo.done} : todo );
    const todos = todoList.map(todo => {
      if (todo.id === id) {
        // return todo.done = !todo.done;             // Error
        return { ...todo, done: !todo.done }
      } else {
        return todo;
      }
    });
    setTodoList(todos);
    */

    setTodoList((todoList) => {
      const todos = todoList.map(todo => {
        if (todo.id === id) {
          // return todo.done = !todo.done;             // Error
          return { ...todo, done: !todo.done }
        } else {
          return todo;
        }
      });
      return todos;
    });
  }, []);

  const deleteTodo = useCallback((id) => {
    /*
    const todos = todoList.filter(todo => todo.id !== id ? true : false);
    setTodoList(todos);
    */
    setTodoList((todoList) => {
      const todos = todoList.filter(todo => todo.id !== id ? true : false);
      return todos;
    })
  }, [])

  const addTodo = useCallback((text) => {
    const todo = { id: cnt.current++, text, done: false };
    // setTodoList(todoList.concat(todo));
    setTodoList((todoList) => todoList.concat(todo));
  }, [])

  return (
    <div>
      <h3>Todo List</h3>

      <TodoForm addTodo={addTodo}></TodoForm>
      <TodoList
        todoList={todoList} updateTodo={updateTodo} deleteTodo={deleteTodo}>
      </TodoList>
    </div>
  );
};
export default TodoTemplate;
