import { useState } from 'react';
import A01ClassState from './components/A01ClassState'
import A02ClassProps from './components/A02ClassProps'
import A03FuncState from './components/A03FuncState'
import A04FuncProps from './components/A04FuncProps'
import A05FuncEvent from './components/A05FuncEvent'
import A06CreateDOM from './components/A06CreateDOM'
import A07Hook from './components/A07Hook'
import A08Hook from './components/A08Hook'
import A09HigherOrder from './components/A09HigherOrder'
import A09Two from './components/A09Two'
import A10Immer from './components/A10Immer'
import A11Currency from './components/A11Currency'

function App() {
  const address = 'Seoul';
  const onAdd = (x, y) => `${x} + ${y} = ${x + y}`

  // 함수에서 state 변수
  // state 변수는 값이 변경되면 사용하고 있는 자식 컴퍼넌트도 모두 해당 값으로 갱신 해 준다
  // const [Getter, Setter] = useState(default Value);
  const [count, setCount] = useState(1);
  const increase = () => setCount(count + 1);

  return (
    <div className="m-3">
      <h1>Chap03 Component</h1>

      <A11Currency></A11Currency><br />

      <A10Immer></A10Immer><br />

      <A09Two num={30}></A09Two><br />
      <A09HigherOrder name="Hello World"></A09HigherOrder><br />

      <A08Hook></A08Hook><br />
      <A07Hook></A07Hook><br />

      <A06CreateDOM></A06CreateDOM><br />
      <A05FuncEvent></A05FuncEvent><br />

      <A04FuncProps name="방자" age="20" num={30} add={address} count={count} increase={increase} onAdd={onAdd}>
        <div>이 컴포넌트는 함수형 컴포넌트</div>
      </A04FuncProps><br />
      <A03FuncState></A03FuncState><br />

      {/* 
        상위 컴퍼넌트가 하위 컴퍼넌트에 데이터 전달은 속성 방식이다.
        데이터 전달은 상위 컴퍼넌트가 하위 컴퍼넌트에게 전달하는 방식만 허용한다
      */}
      <A02ClassProps name="놀부" age="30" num={30} add={address} count={count} increase={increase} onAdd={onAdd} >
        <div>이 내부의 뷰가 자식 컴퍼넌트의 children 태그에 표시된다</div>
      </A02ClassProps><br />

      <A02ClassProps name="흥부" age="40" num={50} add={address} count={count} increase={increase} onAdd={onAdd} >
        <div>이 내부의 뷰는 위와 다르다...</div>
      </A02ClassProps><br />
      <button onClick={increase}>INCREASE</button>

      <A01ClassState></A01ClassState>
    </div>
  );
}

export default App;
