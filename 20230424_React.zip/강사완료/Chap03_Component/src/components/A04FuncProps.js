// A04FuncProps.js
import React from 'react'
import PropTypeCheck from 'prop-types'

// 함수의 첫번째 매개변수가 전달된 속성을 받기 위한 변수(객체)
function A04FuncProps(props) {
  // 디스트럭처링
  const { name, age, num, add, count, increase, onAdd, children } = props

  return (
    <div>
      <h3>A04FuncProps</h3>
      <div>
        Name: {props.name}<br />
        Age: {props.age + 1}<br />
        Num: {props.num + 1}<br />
        Address: {props.add}<br /> {/* 전달한 속성 이름이 add */}
        Count: {props.count}<br />
        Function {props.onAdd(10, 30)}<br />
        Children: {props.children}
        <button onClick={props.increase}>IN</button>
      </div>

      <div>
        Name: {name}<br />
        Age: {age + 1}<br />
        Num: {num + 1}<br />
        Address: {add}<br /> {/* 전달한 속성 이름이 add */}
        Count: {count}<br />
        Function {onAdd(10, 30)}<br />
        Children: {children}
        <button onClick={increase}>IN</button>
      </div>

      <div>
        없는 속성 참조<br />
        TEL: {props.tel}<br />       {/* 에러 아님 */}
        USER: {props.user && props.user.name}<br />      {/* 객체는 에러 남 */}
        Obj: {props.obj.name}
      </div>
    </div>
  )
}

export default A04FuncProps

// 부모 컴포넌트에서 넘어오지 않을 수도 있는 속성의 기본값을 할당할 목적으로 정의한다
A04FuncProps.defaultProps = {
  name: '값이 넘오오지 않았습니다',
  age: 0,
  obj: { name: 'unknown' }
}
// 부모 컴포넌트에서 넘어오는 속성의 타입을 체크.
// 체크하는 모듈을 import 해야 한다. vite로 만든 프로젝트에서는 설치도 해야 함
A04FuncProps.propTypes = {
  name: PropTypeCheck.string.isRequired,
  age: PropTypeCheck.string,
  num: PropTypeCheck.number,
  onAdd: PropTypeCheck.func,
  user: PropTypeCheck.object,
  arr: PropTypeCheck.array,
}