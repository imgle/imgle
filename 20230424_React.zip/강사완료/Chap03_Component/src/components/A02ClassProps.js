// A02ClassProps.js
import React, { Component } from 'react'
import PropTypeCheck from 'prop-types'

export class A02ClassProps extends Component {

  render() {
    // props가 객체이므로 디스트럭처링 구문을 이용해서 사용
    const { name, age, num, add, count, increase, onAdd, children } = this.props

    return (
      <div>
        <h3>A02Class Props - [Immutable - 참조만 가능]</h3>

        <div>
          {/* 상위 컴포넌트에서 전달한 속성은 내장 객체 props로 받아 처리한다 */}
          Name: {this.props.name}<br />
          Age: {this.props.age + 1}<br />
          Num: {this.props.num + 1}<br />
          Address: {this.props.add}<br /> {/* 전달한 속성 이름이 add */}
          Count: {this.props.count}<br />
          Function {this.props.onAdd(10, 30)}<br />
          Children: {this.props.children}
          <button onClick={this.props.increase}>IN</button>
        </div>

        <div>
          Name: {name}<br />
          Age: {age + 1}<br />
          Num: {num + 1}<br />
          Address: {add}<br /> {/* 전달한 속성 이름이 add */}
          Count: {count}<br />
          Function {onAdd(10, 30)}<br />
          Children: {children}
          <button onClick={increase}>IN</button>
        </div>

        <div>
          없는 속성 참조<br />
          TEL: {this.props.tel}<br />       {/* 에러 아님 */}
          USER: {this.props.user && this.props.user.name}<br />      {/* 객체는 에러 남 */}
          Obj: {this.props.obj.name}
        </div>
      </div>
    )
  }
}

export default A02ClassProps

// 부모 컴포넌트에서 넘어오지 않을 수도 있는 속성의 기본값을 할당할 목적으로 정의한다
A02ClassProps.defaultProps = {
  name: '값이 넘오오지 않았습니다',
  age: 0,
  obj: { name: 'unknown' }
}

// 부모 컴포넌트에서 넘어오는 속성의 타입을 체크.
// 체크하는 모듈을 import 해야 한다. vite로 만든 프로젝트에서는 설치도 해야 함
A02ClassProps.propTypes = {
  name: PropTypeCheck.string.isRequired,
  age: PropTypeCheck.string,
  num: PropTypeCheck.number,
  onAdd: PropTypeCheck.func,
  user: PropTypeCheck.object,
  arr: PropTypeCheck.array,
}