import React from "react";
import A09InnerFunc from './A09InnerFunc'

function A09HigherOrder(props) {
  const { age, changeAge } = props;

  return (
    <div>
      <h3>A09 Higher Order Component</h3>
      props: {props.name}
      <br />

      Age: {age}
      <br />

      <button onClick={() => changeAge(100)}>AGE</button>
    </div>
  );
}

export default A09InnerFunc(A09HigherOrder);
