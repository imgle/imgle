// A03FuncState.js
import React, { useState } from 'react'

// state가 변경될때마다 이 함수가 재 호출된다.
function A03FuncState() {
  let compName = 'A03Function State';
  const changeCompName = () => compName = 'Hello World';

  // 메모이제이션
  // 상태관리 변수. 클래스의 this.state = { }
  // 화면이 리렌더링되더라도 값이 유지된다
  const [name, setName] = useState('NolBu');
  const [age, setAge] = useState(10);
  const [arr, setArr] = useState([10, 20]);
  const [user, setUser] = useState({
    name: 'A',
    num: 1
  });

  const changeName = () => setName('Hello World');
  const changeAge = (x) => setAge(x);
  const addArray = () => {
    const random = Math.ceil(Math.random() * 100);
    const newArr = arr.concat(random);
    setArr(newArr);
  }
  const updateArray = (index, value) => {
    const newArr = arr.map((item, i) => index === i ? value : item)
    setArr(newArr);
  }
  const deleteArray = (index) => {
    const newArr = arr.filter((item, i) => index !== i)
    setArr(newArr);
  }
  const addObject = (key, value) => setUser({ ...user, [key]: value });
  const updateObject = (key, value) => setUser({ ...user, [key]: value });
  const deleteObject = (key) => {
    delete user[key]
    setUser({ ...user });
  }

  return (
    <div>
      <h3>A03Function State / {compName}</h3>

      <div>
        Name: {name}<br />
        Age: {age}<br />
        Array: {arr[0]} / {arr[1]} / {arr[2]}<br />
        User: {user.name} / {user.num} / {user.address}
      </div>

      <div>
        <button onClick={changeCompName}>Comp</button>
        <button onClick={changeName}>Name</button>
        <button onClick={() => changeAge(30)}>Age</button><br />

        <button onClick={addArray}>Add Array</button>
        <button onClick={() => updateArray(1, 2000)}>Update Array</button>
        <button onClick={() => deleteArray(1)}>Delete Array</button>

        <button onClick={() => addObject('address', 'Seoul')}>Add Object</button>
        <button onClick={() => updateObject('address', 'Busan')}>Update Object</button>
        <button onClick={() => deleteObject('address')}>Delete Object</button>
      </div>
    </div>
  )
}

export default A03FuncState
