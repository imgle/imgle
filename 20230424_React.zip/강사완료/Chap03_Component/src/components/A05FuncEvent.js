import React, { useState } from 'react'

function A05FuncEvent() {
  const [data, setData] = useState({
    name: '',
    age: 10,
    date: '2023-12-25',
    sports: 'soccer',
    isChecked: true,
    language: ['React'],
    baseball: '',
    four: []
  });

  /*
  const changeString = (evt) => {
    const newData = { ...data, [evt.target.name]: evt.target.value }
    setData(newData);
  }
  */
  const changeString = (evt) => setData({ ...data, [evt.target.name]: evt.target.value });
  const changeNumber = (evt) => {
    let value = Number(evt.target.value);
    if (isNaN(value)) value = 0;
    const newData = { ...data, [evt.target.name]: value }
    setData(newData);
  }
  const changeCheck = (evt) => {
    const newData = { ...data, isChecked: !data.isChecked }
    setData(newData)
  }

  const changeLanguage = (evt) => {
    const value = evt.target.value;
    if (!data.language.includes(value)) {
      const newLang = data.language.concat(value);
      setData({ ...data, language: newLang });
    } else {
      const newLang = data.language.filter((item) => item !== value)
      setData({ ...data, language: newLang });
    }
  }
  const changeSelect = (evt) => {
    const elem = evt.target.selectedOptions
    const elemArr = Array.from(elem);
    const newFour = elemArr.map(item => item.value);
    setData({ ...data, four: newFour })
  }

  const sendData = (evt) => {
    // DOM 요소가 빌드될때 만들어지는 내장 자바스크립트 명령을 취소(실행안함)
    evt.preventDefault();

    // console.log(data)
    if (data.name.trim().length !== 0) {
      console.log(data)
    }
  }
  return (
    <div>
      <h3>A05 Function Component Event & Form</h3>

      <form>
        Name: {data.name}
        <input type="text" name="name" className="form-control" onChange={changeString} />
        Age: {data.age + 1}
        <input type="text" name="age" className="form-control"
          value={data.age} onChange={changeNumber} />
        Date: {data.date}
        <input type="date" name="date" className="form-control"
          defaultValue={data.date} onChange={changeString} />

        RadioButton: {data.sports}<br />
        <div className="form-check">
          <input type="radio" name="sports" value="baseball" id="baseball" className="form-check-input"
            onChange={changeString} defaultChecked={data.sports === 'baseball'} />
          <label htmlFor="baseball" className="form-check-label">야구</label>
        </div>
        <div className="form-check">
          <input type="radio" name="sports" value="soccer" id="soccer" className="form-check-input"
            onChange={changeString} defaultChecked={data.sports === 'soccer'} />
          <label htmlFor="soccer" className="form-check-label">축구</label>
        </div>
        <div className="form-check">
          <input type="radio" name="sports" value="basketball" id="basketball" className="form-check-input"
            onChange={changeString} defaultChecked={data.sports === 'basketball'} />
          <label htmlFor="basketball" className="form-check-label">농구</label>
        </div>

        CheckBox One: {data.isChecked ? '동의' : '동의 안함'}<br />
        <div className="form-check">
          <input type="checkbox" name="isChecked" className="form-check-input"
            value={data.isChecked} onChange={changeCheck}
            defaultChecked={data.isChecked} />
          <label htmlFor="check" className="form-check-label">동의</label>
        </div>

        CheckBox: {data.language.join(' - ')} <br />
        <div className="form-check">
          <input type="checkbox" name="language" value="Angular" id="angular" className="form-check-input"
            onChange={changeLanguage} defaultChecked={data.language.includes('Angular')} />
          <label htmlFor="baseball" className="form-check-label">앵귤러</label>
        </div>
        <div className="form-check">
          <input type="checkbox" name="language" value="React" id="react" className="form-check-input"
            onChange={changeLanguage} defaultChecked={data.language.includes('React')} />
          <label htmlFor="react" className="form-check-label">리엑트</label>
        </div>
        <div className="form-check">
          <input type="checkbox" name="language" value="Vue" id="vue" className="form-check-input"
            onChange={changeLanguage} defaultChecked={data.language.includes('Vue')} />
          <label htmlFor="vue" className="form-check-label">뷰</label>
        </div>

        SelectBox: {data.baseball}<br />
        <select name="baseball" className="form-control"
          value={data.baseball} onChange={changeString} >
          <option>NC</option>
          <option>두산</option>
          <option>엘지</option>
        </select>

        SelectBox Multi: {data.four.join(' * ')}<br />
        <select name="four" multiple size="3" className="form-control"
          onChange={changeSelect}>
          <option>NC</option>
          <option>두산</option>
          <option>엘지</option>
        </select>
        <br />

        <button type="submit" onClick={sendData}>SEND</button>
      </form>
    </div>
  )
}

export default A05FuncEvent
