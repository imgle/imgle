import React, { useCallback, useEffect, useMemo, useReducer } from "react";

const A08Reducer = (state, action) => {
  // console.log(state)
  // console.log(action)
  switch (action.type) {
    case 'CHANGE_NUMBER':
      let value = Number(action.payload.value);
      if (isNaN(value)) value = 0;
      return { ...state, [action.payload.name]: value }
    case 'CHANGE_STRING':
      return { ...state, [action.payload.name]: action.payload.value }
    case 'CHANGE_TODAY':
      return { ...state, today: new Date() }
    case 'ADD_LIST':
      return { ...state, list: state.list.concat(state.avg) }
    default:
      return state;
  }
};

function A08Hook() {
  // 모든 state 변수를 일괄 관리한다. 처리 로직도 외부 함수로 분리한다
  // const [Getter, 처리로직함수 참조변수] = useReducer(처리로직함수, {
  const [data, dispatch] = useReducer(A08Reducer, {
    num: 0,
    str: '',
    today: new Date(),
    avg: '',
    list: [],
  });

  const changeNumber = useCallback((evt) => {
    // dispatch({ type: 'CHANGE_NUMBER', payload: evt.target.value })
    dispatch({ type: 'CHANGE_NUMBER', payload: evt.target })
  }, []);
  const changeString = useCallback((evt) => {
    dispatch({ type: 'CHANGE_STRING', payload: evt.target })
  }, []);
  const addList = useCallback(() => {
    dispatch({ type: 'ADD_LIST' })
  }, []);

  useEffect(() => {
    setTimeout(() => {
      dispatch({ type: 'CHANGE_TODAY' })
    }, 2000);
  }, [])

  const getAverage = (arr) => {
    console.log('계산중...');
    if (arr.length === 0) return 0;
    const total = arr.reduce((sum, item) => sum + item, 0);
    return total / arr.length;
  }

  const getAverageMemo = useMemo(() => {
    return getAverage(data.list)
  }, [data.list])

  return (
    <div>
      <h3>A08. Reducer</h3>

      <div>
        Num: {data.num}
        <input type="text" name="num" className="form-control" onChange={changeNumber} />
        <br />

        Str: {data.str}
        <input type="text" name="str" className="form-control" onChange={changeString} />
        <br />

        Today: {data.today.toLocaleString()}<br />
        <br />

        Avg: {data.avg} / {data.list.join(' - ')} / {getAverageMemo}
        <div className="input-group">
          <input type="text" name="avg" className="form-control" onChange={changeNumber} />
          <button className="btn btn-outline-primary btn-sm" onClick={addList}>ADD</button>
        </div>
      </div>
    </div>
  );
}
export default A08Hook;
