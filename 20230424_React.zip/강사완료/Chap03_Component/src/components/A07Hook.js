import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

function A07Hook() {
  // 1. useState
  // 값 유지. 값 변경시 변경된 값으로 화변 갱신(리 렌더링 - 이 함수 재 호출)
  const [data, setData] = useState({
    num: '',
    str: '',
    avg: '',
    list: []
  });
  const [today, setToday] = useState(new Date());

  // 2. useCallback
  // Event Handler
  // const handlerName = useCallback(EventHandler, [의존관계]);
  // 의존관계가 []라면 EventHandler에서 사용한 변수값을 그대로 보전한 상태로 
  // 메모리에 올라감. 즉 data는 최초의 값 { num: 0, str: ''}를 기억하고
  // 이벤트가 발생할때 마다 이 값을 기반으로 변경을 함
  /*
  const changeNumber = useCallback((evt) => {
    let value = Number(evt.target.value);
    if (isNaN(value)) value = '';
    const newData = { ...data, [evt.target.name]: value };
    setData(newData)
  }, [data]);   // data 값이 변경될때마다 이 핸들러를 새롭게 생성해라

  const changeString = useCallback((evt) => {
    const newData = { ...data, [evt.target.name]: evt.target.value };
    setData(newData)
  }, [data]);
  */

  const changeNumber = useCallback((evt) => {
    // setData(newValue);
    // setData((자신의 Getter의 참조값) => { return newValue})

    setData((x) => {     // 여기서 x는 setData의 Getter인 data를 의미한다
      let value = Number(evt.target.value);
      if (isNaN(value)) value = '';
      const newData = { ...x, [evt.target.name]: value };
      return newData;
    })
  }, []);   // data 값이 변경될때마다 이 핸들러를 새롭게 생성해라
  const changeString = useCallback((evt) => {
    setData((x) => ({ ...x, [evt.target.name]: evt.target.value }))
  }, []);

  const addList = useCallback(() => {
    setData((data) => {
      if (data.avg) {
        return { ...data, list: data.list.concat(data.avg) }
      }
    })
  }, []);


  // 3. LifeCycle Hook
  // [] 없음 => 리 렌더링될때마다 실행된다
  // [] 있고 의존관계를 가진 변수가 없음 => 최초 1번만 실행된다
  //      class의 lifeCycle 메소드 componentDidMounted와 동일
  // [] 있고 의존관계를 가진 변수가 있음 => 의존관계를 가진 변수가 변경될때마다 실행
  //      class의 lifeCycle 메소드 componentDidUpdated와 동일
  useEffect(() => {
    setTimeout(() => {
      setToday(new Date());
    }, 3000)
  }, [data]);     // data의 값이 변경될때마다 재 실행된다


  // 4. useRef
  // 시작하자마자 num 필드의 background 색을 orange로 할당
  // 아래는 리렌더링 될때마다 매번 실행된다
  // document.querySelector('input[name="num"]').style.background = 'orange';
  // const cnt = useRef(value);       // 값 유지 목적
  const numRef = useRef(null);        // DOM 참조 목적. 요소에 ref={numRef} 형태로 할당

  useEffect(() => {
    document.querySelector('input[name="num"]').style.background = 'orange';
    // numRef.current => document.querySelector('input[name="num"]')
    numRef.current.style.color = 'white'
  }, []);         // 최초 1번 실행 후 재 실행되지 않는다


  // 5. useMemo => 일반 함수를 메모이제이션
  //    useCallback => 이벤트 핸들러를 메모이제이션
  const getAverage = (arr) => {
    console.log('계산중...');
    if (arr.length === 0) return 0;
    // [1,2,3]
    // (0, 1) => 1, (1, 2) => 3, (3, 3) => 6
    const total = arr.reduce((sum, item) => sum + item, 0);
    return total / arr.length;
  }

  // 사용할때 프로퍼티(속성) 형태로 호출해서 사용한다
  const averageMemo = useMemo(() => {
    return getAverage(data.list)
  }, [data.list])

  return (
    <div>
      <h3>A07. useState, useEffect</h3>

      <div>
        Num: {data.num}
        <input type="number" name="num" className="form-control" ref={numRef}
          onChange={changeNumber} value={data.num} />
        <br />

        Str: {data.str}
        <input type="text" name="str" className="form-control"
          onChange={changeString} />
        <br />

        Today: {today.toLocaleString()}<br />
        <br />

        Avg: {data.avg} / {data.list.join(' - ')} / {averageMemo}
        <div className="input-group">
          <input type="text" name="avg" className="form-control" onChange={changeNumber} />
          <button className="btn btn-outline-primary btn-sm" onClick={addList}>ADD</button>
        </div>
      </div>
    </div>
  );
}
export default A07Hook;
