// A09InnerFunc.js

import { useCallback, useState } from "react";

function A09InnerFunc(Comp) {

  const InnerFunc = (props) => {
    const [age, setAge] = useState(10);
    const changeAge = useCallback((num) => {
      setAge(num);
    }, []);

    return <Comp {...props} age={age} changeAge={changeAge} />
  }
  return InnerFunc;
}
export default A09InnerFunc;
