import React, { useCallback, useState } from "react";

// 고정값
const rate = { 'USD': 1, EUR: 0.98, KRW: 0.00072 };
const currencies = ['USD', 'EUR', 'KRW'];

function A11Currency() {
  const [data, setData] = useState({
    qty: 3,
    cost: 5,
    inCurr: 'USD'
  });

  const changeNumber = useCallback((evt) => {
    setData(data => ({ ...data, [evt.target.name]: Number(evt.target.value) }))
  }, [])
  const changeCountry = useCallback((evt) => {
    setData(data => ({ ...data, inCurr: evt.target.value }))
  }, [])

  const getTotal = () => {
    const result = currencies.map(item => {
      const total = (data.qty * data.cost * rate[data.inCurr] / rate[item]).toFixed(2);
      return <span key={item}>{item}: {total} &nbsp; {' '}</span>
    });
    // console.log(result);
    return result;
  }

  return (
    <div>
      <h3>A11 Currency</h3>

      Qty: <input type="number" name="qty" className="form-control"
        value={data.qty} onChange={changeNumber} />
      Cost: <input type="number" name="cost" className="form-control"
        value={data.cost} onChange={changeNumber} />
      Country:
      <select className="form-control" name="inCurr" onChange={changeCountry}>
        {currencies.map(item => <option key={item}>{item}</option>)}
      </select>
      <br />

      <div>Total: {data.qty * data.cost}</div>
      <div>Total: {getTotal()}</div>
    </div>
  );
}
export default A11Currency;
