import React, { useCallback, useState } from "react";
import produce from 'immer'

function A10Immer() {
  const [person, setPerson] = useState({
    name: "",
    info: {
      address: "",
      tel: [10, 20, 30],
      etc: {
        one: "",
        two: "",
      },
    },
  });

  const changeName = useCallback(() => {
    setPerson((person) => ({ ...person, name: 'NolBu' }))
  }, []);
  const changeAddress = useCallback(() => {
    setPerson((person) => {
      return {
        ...person,
        info: {
          ...person.info,
          address: 'Seoul'
        }
      }
    })
  }, []);
  const changeOne = useCallback(() => {
    setPerson((person) => {
      return {
        ...person,
        info: {
          ...person.info,
          etc: {
            ...person.info.etc,
            one: '복잡하다...'
          }
        }
      }
    })
  }, []);
  const addArray = useCallback(() => {
    const random = Math.ceil(Math.random() * 100);
    setPerson((person) => {
      return {
        ...person,
        info: {
          ...person.info,
          tel: person.info.tel.concat(random)
        }
      }
    })
  }, []);

  // immer
  const changeNameImmer = useCallback(() => {
    /*
    // person 의존관계를 할당해야 한다
    const newData = produce(person, draft => {
      draft.name = '흥부';
    })
    // console.log(newData);
    setPerson(newData);
    */

    setPerson((person) => {
      const newData = produce(person, draft => {
        draft.name = '흥부';
      })
      return newData;
    });
  }, [])

  const changeAddressImmer = useCallback((x) => {
    setPerson((person) => {
      const newData = produce(person, draft => {
        // 객체 참조 표기법을 그대로 이용한다
        draft.info.address = x;
      })
      return newData;
    });
  }, []);

  const changeOneImmer = useCallback(() => {
    setPerson((person) => {
      const newData = produce(person, draft => {
        draft.info.etc.one = '간단하네...';
      })
      return newData;
    });
  }, []);

  const addArrayImmer = useCallback(() => {
    const random = Math.ceil(Math.random() * 100);
    setPerson((person) => {
      const newData = produce(person, draft => {
        draft.info.tel.push(random);
      })
      return newData;
    });
  }, []);
  const updateArrayImmer = useCallback((index, value) => {
    setPerson((person) => {
      const newData = produce(person, draft => {
        draft.info.tel[index] = value;
      })
      return newData;
    });
  }, []);
  const deleteArrayImmer = useCallback((index) => {
    setPerson((person) => {
      const newData = produce(person, draft => {
        draft.info.tel.splice(index, 1);
      })
      return newData;
    });
  }, [])

  return (
    <div>
      <h3>A10 Immer</h3>

      Name: {person.name}
      <br />

      Address: {person.info.address}
      <br />

      One: {person.info.etc.one}
      <br />

      Ary:{" "}
      {person.info.tel.map((item, i) => (
        <span key={i}>{item} </span>
      ))}
      <br />

      <button onClick={changeName}>Name</button>
      <button onClick={changeAddress}>Address</button>
      <button onClick={changeOne}>One</button>
      <button onClick={addArray}>ADD</button>
      <br />

      <button onClick={changeNameImmer}>Name</button>
      <button onClick={() => changeAddressImmer('Busan')}>Address</button>
      <button onClick={changeOneImmer}>One</button>

      <button onClick={addArrayImmer}>ADD</button>
      <button onClick={() => updateArrayImmer(1, 2000)}>UPDATE</button>
      <button onClick={() => deleteArrayImmer(1)}>DELETE</button>
    </div>
  );
}
export default A10Immer;
