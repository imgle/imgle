// A01ClassState.js
import React from 'react'

class A01ClassState extends React.Component {
  constructor() {
    super();

    // 참조 변수
    this.compName = 'A01ClassState';

    // 상태 관리 변수. (Getter)
    // 이 변수의 값이 변경되면 리엑트는 변경된 값을 기반으로 화면을 재 구성(리렌더링)한다
    // 불변성 유지
    // 변경 => 항상 새로운 값. 여기서는 state가 오브젝트 객체(주소값)다.

    // state는 constructor에서 분리해서 독립적으로 사용 가능
    /*
    this.state = {
      name: 'NolBu',
      age: 20,
      arr: [10, 20],
      user: { name: 'A', num: 1 }
    }
    */
  }

  state = {
    name: 'NolBu',
    age: 20,
    arr: [10, 20],
    user: { name: 'A', num: 1 }
  }


  changeCompName = () => {
    console.log(this);
    this.compName = 'Hello World';
  }
  changeName = (evt) => {
    console.log(evt.target)
    // state를 변경하기 위해 정의되어 있는 Setter 함수
    // const newState = {...this.state, name: '흥부'}
    this.setState({ name: '흥부' })
  }
  changeAge = (num, evt) => {
    this.setState({ age: num });
    evt.target.style.background = 'orange'
  }

  addArray = () => {
    const random = Math.ceil(Math.random() * 100);
    // console.log(random)
    const newArr = this.state.arr.concat(random);
    this.setState({ arr: newArr })
  }
  updateArray = (index, value) => {
    // this.state.arr[index] = value;
    const newArr = this.state.arr.map((item, i) => {
      if (index === i) return value;
      else return item;
    })
    this.setState({ arr: newArr })
  }
  deleteArray = (index) => {
    const newArr = this.state.arr.filter((item, i) => {
      if (index === i) return false;
      else return true;
    })
    this.setState({ arr: newArr })
  }

  addUser = (key, value) => {
    const newUser = { ...this.state.user, [key]: value };
    this.setState({ user: newUser });
  }
  updateUser = (key, value) => {
    const newUser = { ...this.state.user, [key]: value };
    this.setState({ user: newUser });
  }
  deleteUser = (key) => {
    delete this.state.user[key];              // 기존 객체에서 삭제 (주소값 그대로인 상태)
    const newUser = { ...this.state.user };   // 삭제한거 빼고 새롭게 생성
    this.setState({ user: newUser });
  }


  // 반드시 override 해야 한다
  render() {
    return (
      <div>
        <h3>A01ClassState / {this.compName}</h3>

        <div>
          Name: {this.state.name}<br />
          Age: {this.state.age}<br />
          Array: {this.state.arr[0]} / {this.state.arr[1]} / {this.state.arr[2]}<br />
          User: {this.state.user.name} / {this.state.user.num} / {this.state.user.address}
        </div>

        <div>
          <button onClick={this.changeCompName}>COMP</button>
          <button onClick={this.changeName}>Name</button>
          <button onClick={(evt) => this.changeAge(1000, evt)}>Age</button><br />

          <button onClick={this.addArray}>Add Array</button>
          <button onClick={() => this.updateArray(1, 2000)}>Update Array</button>
          <button onClick={() => this.deleteArray(1)}>Delete Array</button>

          <button onClick={() => this.addUser('address', 'Seoul')}>Add Object</button>
          <button onClick={() => this.updateUser('address', 'Busan')}>Update Object</button>
          <button onClick={() => this.deleteUser('address')}>Delete Object</button>
        </div>
      </div >
    )
  }
}
export default A01ClassState;
