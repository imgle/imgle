import React from 'react'
import A09InnerFunc from './A09InnerFunc'

function A09Two(props) {
  const { num, age, changeAge } = props;

  return (
    <div>
      Age: {num} / {age}<br />
      <button onClick={() => changeAge(3000)}>Click</button>
    </div>
  )
}

export default A09InnerFunc(A09Two)