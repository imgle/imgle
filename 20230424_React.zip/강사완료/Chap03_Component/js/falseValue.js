const value = undefined;

// 변수의 값이 undefined, null, 0, '', NaN, false는 모두 false 취급한다
if (value) {
  console.log('False')
}

console.log(!!undefined);
console.log(!!null);
console.log(!!0);
console.log(!!'');
console.log(!!NaN);

console.log(!!10);
if (this.addEventListener) {
  console.log('지원 함')
}

console.log('------------- END -----------')