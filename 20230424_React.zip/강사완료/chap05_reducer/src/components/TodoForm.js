import React, { useRef } from "react";

function TodoForm(props) {
  const { addTodo, txt, changeText } = props;
  const todoRef = useRef();

  const sendData = (evt) => {
    evt.preventDefault();
    if (txt.trim().length !== 0) {
      addTodo(txt);
      changeText('');     // 이 메서드가 txt 값을 바꾸는 메서드다
      todoRef.current.focus();
    }
  }

  return (
    <form>
      <div className="input-group">
        <input type="text" className="form-control" ref={todoRef}
          value={txt} onChange={(evt) => changeText(evt.target.value)} />
        <div className="input-group-append">
          <button type="submit" className="btn btn-primary mr-1" onClick={sendData}>Submit</button>
        </div>
      </div>
    </form>
  );
}
export default TodoForm;
