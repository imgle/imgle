import React, { useCallback, useReducer, useRef } from "react";
// immer 10 버전부터는 default가 아니다
import { produce } from 'immer'

import TodoForm from './TodoForm'
import TodoList from './TodoList'

const makeTodo = () => {
  const todos = [];
  for (let i = 1; i <= 5000; i++) {
    todos.push({ id: i, text: `${i}번째 할 일`, done: false });
  }
  return todos;
};

const todoReducer = (state, action) => {
  switch (action.type) {
    case 'TODOLIST_UPDATETODO':
      /*
      const todos = state.todoList.map(todo => {
        if (todo.id === action.payload) return { ...todo, done: !todo.done }
        else return todo;
      });
      return { ...state, todoList: todos };
      */

      // state 값 전체를 변경한 값 기반으로 모두 바꾸어 새로운 객체를 리턴해 준다
      const newState = produce(state, draft => {
        // draft.todoList[action.payload].done = !draft.todoList[action.payload].done;
        const todo = draft.todoList.find(item => item.id === action.payload);
        todo.done = !todo.done;
      })
      return newState
    case 'TODOLIST_DELETETODO':
      /*
      const newData = state.todoList.filter(todo => todo.id !== action.payload)
      return { ...state, todoList: newData }
      */
      const index = state.todoList.findIndex(item => item.id === action.payload);
      const newData = produce(state, draft => {
        draft.todoList.splice(index, 1);
      })
      return newData;

    case 'TODOLIST_ADDTODO':
      // return { ...state, todoList: state.todoList.concat(action.payload) }
      const addData = produce(state, draft => {
        draft.todoList.push(action.payload);
      });
      return addData;

    case 'TODOLIST_CHANGETEXT':
      // return { ...state, txt: action.payload }
      const txtData = produce(state, draft => {
        draft.txt = action.payload;
      });
      return txtData;

    default:
      return state;
  }
}

const TodoTemplate = () => {
  const [data, dispatch] = useReducer(todoReducer, {
    todoList: makeTodo(),
    txt: ''
  });
  const cnt = useRef(5001);

  // Event Handler
  const updateTodo = useCallback((id) => {
    dispatch({ type: 'TODOLIST_UPDATETODO', payload: id })
  }, []);
  const deleteTodo = useCallback((id) => {
    dispatch({ type: 'TODOLIST_DELETETODO', payload: id })
  }, []);
  const addTodo = useCallback((text) => {
    const todo = { id: cnt.current++, text, done: false };
    dispatch({ type: 'TODOLIST_ADDTODO', payload: todo })
  }, []);
  const changeText = useCallback((txt) => {
    dispatch({ type: 'TODOLIST_CHANGETEXT', payload: txt })
  }, [])

  return (
    <div>
      <h3>Todo List</h3>

      <TodoForm addTodo={addTodo} txt={data.txt} changeText={changeText}></TodoForm>
      <TodoList todoList={data.todoList} updateTodo={updateTodo} deleteTodo={deleteTodo}></TodoList>
    </div>
  );
};
export default TodoTemplate;
