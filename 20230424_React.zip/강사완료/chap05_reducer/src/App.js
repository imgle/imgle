import TodoTemplate from './components/TodoTemplate'

function App() {
  return (
    <div className="m-3">
      <h1>TodoList Reducer</h1>

      <TodoTemplate></TodoTemplate>
    </div>
  );
}

export default App;
