import { nickname, num, arr, onAdd } from './modules/A12Export'
import app from './modules/A12ExportDefault'
import $ from 'jquery'

console.log(num);
const dom = `
  <div>
    <h3>Webpack Test</h3>
    <div>
      Nickname: ${nickname}<br>
      Num: ${num}<br>
      Array: ${arr[0]} / ${arr[1]} / ${arr[10]}<br>
      onAdd: ${onAdd(10, 20)}<br>
    </div>
    <br />

    <div>
      X: ${app.x}<br>
      alert: ${app.alert}<br>
      onMin: ${app.onMin(20, 3)}<br>
    </div>
  </div>
`

// JavaScript
const root = document.getElementById('root');
root.innerHTML = dom;

// jQuery
$(document).ready(function () {
  $('#app').html(dom);
})