import { Link, Navigate, Route, Routes } from "react-router-dom";
import { Suspense, lazy } from "react";
import { Bars, Triangle } from 'react-loader-spinner'

import A02FuncState from './components/A02FuncState'
import A03Currency from './components/A03Currency'
import A04History from './components/A04History'
import A01FuncProps from './components/A01FuncProps'
import A05Param from './components/A05Param'
import A06Args from './components/A06Arguments'

// import A07Child from './components/A07ChildComponent'
// import A08Redirect from './components/A08Redirect'
// import NotFoundComponent from './components/NotFoundComponent'

// lazy Load. 클릭하면 그때 서버로부터 해당 컴퍼넌트를 가져와 표시한다
// 로드 되기전 처리를 해 주어야 한다 
// <Suspence fallback={로딩중 표시될 뷰}><가져올 컴퍼넌트 /></Suspence>
const A07Child = lazy(() => import('./components/A07ChildComponent'))
const A08Redirect = lazy(() => import('./components/A08Redirect'))
const NotFoundComponent = lazy(() => import('./components/NotFoundComponent'))

function App() {
  const user = { name: 'HungBu', age: 20 };
  const ary = ['a', 'b', 'c'];
  const onAdd = (x, y) => `${x} + ${y} = ${x + y}`;

  return (
    <div className="m-3">
      <h1>Chap06 Router</h1>

      <div>
        <Link to="/">INXEX</Link> | {' '}
        <Link to="/A02State">A02State</Link> | {' '}
        <Link to="/A03Currency">A03Currency</Link> | {' '}
        <Link to="/A04History">A04History</Link> | {' '}

        <Link to="/A01FuncProps">A01FuncProps</Link> | {' '}

        <Link to="/A05Param/1/NolBu">A05Param 1</Link> | {' '}
        <Link to="/A05Param/2/흥부">A05Param 2</Link> | {' '}

        <Link to="/A06Args?no=3&name=HangDan#TOP">A06Args 3</Link> | {' '}
        <Link to="/A06Args?no=4&name=방자#BTM">A06Args 4</Link> | {' '}

        <Link to="/A07Child">A07Child</Link> | {' '}
        <Link to="/A08Redirect">A08Redirect</Link> | {' '}
        <Link to="/ABC">ABC</Link> | {' '}
      </div>

      <hr />

      {/* index.js에 Router 전역 세팅 BrowserRouter를 먼저 올려야 한다 */}
      {/* 외부 컴포넌트가 표시될 영역 */}
      <Routes>
        <Route path="/" element={<Navigate to="/A02State" />} />
        <Route path="/A02State" element={<A02FuncState />} />
        <Route path="/A03Currency" element={<A03Currency />} />

        {/* 이동관련 명령 */}
        <Route path="/A04History" element={<A04History />} />

        {/* 데이터 전달 - 속성으로 전달 */}
        <Route path="/A01FuncProps"
          element={<A01FuncProps name="놀부" age={20} arr={ary} user={user} onAdd={onAdd} isChecked={true} />} />
        {/* 데이터 전달 - 패스로 전달 => :이 붙은 패스는 변수명이다
          path="/A05Param/:no/:name" => <Link to="/A05Param/1001/NolBu" .. />
          A05Param 컴포넌트 내부에 다음과 같이 정의한 것과 동일
          const no = '1001';
          const name = 'NolBu';
        */}
        <Route path="/A05Param/:no/:name" element={<A05Param />} />

        {/* 데이터 전달 - 주소줄의 파라메터로 전달. 따라서 여기서 세팅은 없음
          Link에서 값을 전달한다
        */}
        <Route path="/A06Args" element={<A06Args />} />

        {/* 하위 라우터를 구성한다 */}
        <Route path="/A07Child"
          element={<Suspense fallback={<div>Loading....</div>}><A07Child /></Suspense>}>
          {/* A07Child의 Outlet 공간에 표시된다 */}
          <Route path="" element={<h3>ONE</h3>} />        {/* 패스명이 없거나 상위 패스명과 동일하면 기본으로 표시*/}
          <Route path="two" element={<h3>TWO</h3>} />
          <Route path="/A07Child/three" element={<h3>THREE</h3>} />
        </Route>

        {/* 301, 302, 303 리 다이렉트 기능 */}
        <Route path="/A08Redirect"
          element={<Suspense fallback={<Bars />}><A08Redirect /></Suspense>} />

        {/* 위의 모든 패스가 매칭되지 않으면 표시될 컴퍼넌트를 정의한다 */}
        <Route path="*" element={<Suspense fallback={<Triangle />}><NotFoundComponent /></Suspense>} />
      </Routes>
    </div>
  );
}

export default App;

// npm i react-router => React v17 Router 버전 5.x.x를 사용
// npm i react-router-dom => v18 Router 버전 6.x.x를 사용
// npm i react-loader-spinner => loading bar
