import React from 'react'
import { Navigate } from 'react-router-dom';

function A08Redirect() {
  const isChecked = false;

  if (!isChecked) {
    // replace={true}는 history를 남기지 않는다
    return <Navigate to="/" replace={true} />
  }

  return (
    <div>
      <h1>A08Redirect</h1>
    </div>
  )
}

export default A08Redirect