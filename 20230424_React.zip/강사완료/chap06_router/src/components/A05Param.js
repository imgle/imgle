import React from "react";
import { useLocation, useParams } from "react-router-dom";

const data = [
  { id: 1, name: "Apples", category: "Fruit", price: 1.2, expiry: 10 },
  { id: 2, name: "Bananas", category: "Fruit", price: 2.42, expiry: 7 },
  { id: 3, name: "Pears", category: "Fruit", price: 2.02, expiry: 6 },
  { id: 4, name: "Tuna", category: "Fish", price: 20.45, expiry: 3 },
  { id: 5, name: "Salmon", category: "Fish", price: 17.93, expiry: 2 },
  { id: 6, name: "Trout", category: "Fish", price: 12.93, expiry: 4 },
];

function A05MatchParam() {
  // PATH의 값을 받기위한 Hook
  const params = useParams();
  // console.log(params);

  // 주소줄의 값(?no=3&name=방자)
  const location = useLocation();
  console.log(location)

  // const product = data[params.no]      // 자동 캐스팅
  // ==는 자동캐스팅이 이루어지면서 비교
  // ===는 값과 타입을 동시에 비교한다. 따라서 타입이 다르면 
  // product에 undefined가 대입된다
  // 아래 view에서 Id: {product.id} 에서 에러 발생. undefined에는 id 속성 없음
  const product = data.find(item => item.id === Number(params.no))

  return (
    <div>
      <h5>Parameter Component</h5>
      <div>This is Parameter Component</div>
      <br />

      <div>
        Id: {params.no}<br />
        Name: {params.name}<br />
        Location: {location.pathname}
      </div>
      <br />

      <div>
        Id: {product && product.id} <br />
        Name: {product && product.name} <br />
        Category: {product && product.category}
      </div>
    </div>
  );
};
export default A05MatchParam;
