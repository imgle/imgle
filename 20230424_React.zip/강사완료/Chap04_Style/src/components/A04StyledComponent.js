// npm i styled-components
// npm i reactstrap
// npm i react-icons

import React, { useState } from "react";
import { MY_BOX, MY_BTN } from './css/A04Style'

import { Accordion, AccordionBody, AccordionHeader, AccordionItem, Alert, Button, Card, CardBody, CardSubtitle, CardText, CardTitle } from 'reactstrap';
import { MdAddCard } from "react-icons/md";

/*
import styled from 'styled-components'
 
// 내부에서는 SCSS 문법
const MY_BOX = styled.div`
  background: ${props => props.color || 'lightgray'};
  color: white;
  padding: 10px;
  font-size: 14pt;
  line-height: 1em;
`;
const MY_BTN = styled.button`
  background: lightgray;
  color: white;
  padding: 5px;
  line-height: 1em;
 
  &: hover {
    background: orange;
    color: white
  }
`
*/

function A04StyledComponent() {
  const [open, setOpen] = useState('1');
  const toggle = (id) => {
    if (open === id) {
      setOpen();
    } else {
      setOpen(id);
    }
  };

  return (
    <div>
      <h3>A04 Styled Component</h3>

      <MY_BOX>Hello World</MY_BOX>
      <MY_BOX color="orange">Hello World</MY_BOX>

      <MY_BTN>CLICK</MY_BTN>
      <br />
      <br />

      <MdAddCard style={{ fontSize: '24pt', color: 'orange' }} /> Hello World
      <br />
      <br />

      <Card
        style={{
          width: '18rem'
        }}
      >
        <img alt="Sample" src="https://picsum.photos/300/200" />
        <CardBody>
          <CardTitle tag="h5">
            Card title
          </CardTitle>
          <CardSubtitle
            className="mb-2 text-muted"
            tag="h6"
          >
            Card subtitle
          </CardSubtitle>
          <CardText>
            Some quick example text to build on the card title and make up the bulk of the card‘s content.
          </CardText>
          <Button>
            Button
          </Button>
        </CardBody>
      </Card>

      <Alert color="warning">
        Hello World
      </Alert>

      <Accordion open={open} toggle={toggle}>
        <AccordionItem>
          <AccordionHeader targetId="1">Accordion Item 1</AccordionHeader>
          <AccordionBody accordionId="1">
            <strong>This is the first item&#39;s accordion body.</strong>
            You can modify any of this with custom CSS or overriding our default
            variables. It&#39;s also worth noting that just about any HTML can
            go within the <code>.accordion-body</code>, though the transition
            does limit overflow.
          </AccordionBody>
        </AccordionItem>
        <AccordionItem>
          <AccordionHeader targetId="2">Accordion Item 2</AccordionHeader>
          <AccordionBody accordionId="2">
            <strong>This is the second item&#39;s accordion body.</strong>
            You can modify any of this with custom CSS or overriding our default
            variables. It&#39;s also worth noting that just about any HTML can
            go within the <code>.accordion-body</code>, though the transition
            does limit overflow.
          </AccordionBody>
        </AccordionItem>
        <AccordionItem>
          <AccordionHeader targetId="3">Accordion Item 3</AccordionHeader>
          <AccordionBody accordionId="3">
            <strong>This is the third item&#39;s accordion body.</strong>
            You can modify any of this with custom CSS or overriding our default
            variables. It&#39;s also worth noting that just about any HTML can
            go within the <code>.accordion-body</code>, though the transition
            does limit overflow.
          </AccordionBody>
        </AccordionItem>
      </Accordion>
    </div>
  );
}

export default A04StyledComponent;
