import styled from 'styled-components'

export const MY_BOX = styled.div`
  background: ${props => props.color || 'lightgray'};
  color: white;
  padding: 10px;
  font-size: 14pt;
  line-height: 1em;
`;
export const MY_BTN = styled.button`
  background: lightgray;
  color: white;
  padding: 5px;
  line-height: 1em;

  &: hover {
    background: orange;
    color: white
  }
`