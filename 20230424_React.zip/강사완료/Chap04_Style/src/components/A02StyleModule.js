import React from "react";

// fileName.module.css 파일 형태는 default import를 사용한다
// 내부 class는 변수명.className으로 참조한다
import one from './css/A02Style1.module.css'
import two from './css/A02Style2.module.css'

function A02StyleModule() {
  return (
    <div>
      {/* module.css이 붙은 css 파일 내부에서 :global이 붙으면 전역 CSS로 정의된다 */}
      <h3 className={one.title}>A02 Style <span className="innerColor">Module</span> Component</h3>
      <h3 className={`${two.title} ${two.reverse}`}>A02 Style Module Component</h3>
      <h3 className={[two.title, two.reverse].join(' ')}>A02 Style Module Component</h3>
    </div>
  );
}

export default A02StyleModule;
