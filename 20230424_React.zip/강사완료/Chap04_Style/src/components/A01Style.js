import React from "react";

// CSS import
// Head 부분에 올라온다. 클래스 이름이 존재하면 나중에 정의한 값으로 덮어 쓸 수 있다.
import './css/A01Style.css';

// npm i node-sass
// 설치 후 리 스타트 해야 한다
import './css/A01Style.scss';

function A01Style() {
  const title = 'title';
  const color = 'color';
  const check = false;
  const myClass = 'title color';
  const myStyle = { background: 'black', padding: '10px', fontSize: '20pt', color: 'white' }

  return (
    <div>
      <h3 className="title color">A01 Style</h3>
      <h3 className={`${title} ${color}`}>A01 Style</h3>
      <h3 className={[title, color].join(' ')}>A01 Style</h3>
      <h3 className={myClass}>A01 Style</h3>
      <h3 className={check ? myClass : undefined}>A01 Style</h3>

      <h3 style={{ background: 'black', padding: '10px', fontSize: '20pt', color: 'white' }}>A01 Style</h3>
      <h3 style={myStyle}>A01 Style</h3>

      <h3 className="scssTitle">A01 Style</h3>
    </div >
  );
}

export default A01Style;
